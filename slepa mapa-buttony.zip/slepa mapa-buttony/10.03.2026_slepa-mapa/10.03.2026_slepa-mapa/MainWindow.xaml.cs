﻿using _10._03._2026_slepa_mapa;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Linq;

namespace _10._03._2026_slepa_mapa
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<MapPoint> points = new List<MapPoint>()
        {
            new MapPoint(){ Name="Brno", XPercent=0.6766, YPercent=0.7153 },
            new MapPoint(){ Name="Praha", XPercent=0.3476, YPercent=0.3942 },
            new MapPoint(){ Name="Ostrava", XPercent=0.8917, YPercent=0.4599 }
        };

        // Hra
        private List<MapPoint> roundOrder;
        private int currentRound;
        private int totalRounds;
        private int score;
        private MapPoint activePoint;
        private readonly System.Random rng = new System.Random();

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            StartGame();
            DrawPoints();
        }

        void StartGame()
        {
            totalRounds = points.Count;
            // náhodné pořadí kol (můžete zvolit sekvenční pokud chcete)
            roundOrder = points.OrderBy(p => rng.Next()).ToList();
            currentRound = 0;
            score = 0;
            activePoint = roundOrder[currentRound];
            UpdateUI();
        }

        void UpdateUI()
        {
            ActiveText.Text = $"Aktivní město: {activePoint.Name}";
            RoundText.Text = $"Kolo: {currentRound + 1} / {totalRounds}";
            ScoreText.Text = $"Skóre: {score} / {totalRounds}";
        }

        void EndGame()
        {
            MessageBox.Show($"Konec hry. Skóre: {score} / {totalRounds}", "Výsledek");
            // Po skončení můžete hru restartovat
            StartGame();
        }

        private void MapImage_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            DrawPoints();
        }

        void DrawPoints()
        {
            OverlayCanvas.Children.Clear();

            foreach (var point in points)
            {
                double x = MapImage.ActualWidth * point.XPercent;
                double y = MapImage.ActualHeight * point.YPercent;

                Button btn = new Button()
                {
                    Content = point.Name,
                    Tag = point,
                    Width = 90,
                    Height = 26,
                    Padding = new Thickness(4),
                    FontSize = 12
                };

                btn.Click += Btn_Click;

                // jednoduché centrování tlačítka vzhledem k bodu (posun o polovinu šířky/výšky)
                Canvas.SetLeft(btn, x - (btn.Width / 2));
                Canvas.SetTop(btn, y - (btn.Height / 2));

                OverlayCanvas.Children.Add(btn);
            }
        }

        private void Btn_Click(object sender, RoutedEventArgs e)
        {
            if (currentRound >= totalRounds) return; // bezpečnost

            Button btn = sender as Button;
            MapPoint point = btn.Tag as MapPoint;

            bool correct = point.Name == activePoint.Name;

            if (correct)
            {
                score++;
                MessageBox.Show("Správně!", "Odpověď");
            }
            else
            {
                MessageBox.Show($"Špatně. Správná odpověď byla: {activePoint.Name}", "Odpověď");
            }

            // přejít na další kolo
            currentRound++;
            if (currentRound >= totalRounds)
            {
                UpdateUI();
                EndGame();
                return;
            }

            activePoint = roundOrder[currentRound];
            UpdateUI();
        }

        private void MapImage_MouseDown(object sender, MouseButtonEventArgs e)
        {
            var pos = e.GetPosition(MapImage);

            double xPercent = pos.X / MapImage.ActualWidth;
            double yPercent = pos.Y / MapImage.ActualHeight;

            MessageBox.Show($"{xPercent:F4} , {yPercent:F4}");
        }
    }
}